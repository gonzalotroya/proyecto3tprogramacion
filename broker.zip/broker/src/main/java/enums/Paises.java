package enums;

public enum Paises {
	Espa�a,
	UK,
	Alemania,
	Francia,
	Belgica,
	Netherlands,
	Luxemburgo,
	PORTUGAL,
	Austria

}
