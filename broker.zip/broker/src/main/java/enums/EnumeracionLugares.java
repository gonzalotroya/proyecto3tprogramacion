package enums;

public enum EnumeracionLugares {
USA,ESPA�A
}
