package enums;

public enum EnumeracionSectores {
ENERGIA,METALES,AGRICULTURA,TECNOLOGICO
}
