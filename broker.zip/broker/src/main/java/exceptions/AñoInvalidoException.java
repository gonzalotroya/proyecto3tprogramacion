package exceptions;

public class A�oInvalidoException extends Exception{
	public A�oInvalidoException(String msg) {
		super(msg);
	}
}
