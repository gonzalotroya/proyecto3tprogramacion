package exceptions;

public class EmailValidoException extends Exception{
	public EmailValidoException(String msg) {
		super(msg);
	}
}
