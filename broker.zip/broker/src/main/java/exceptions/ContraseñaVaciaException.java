package exceptions;

public class Contrase�aVaciaException extends Exception{
	public Contrase�aVaciaException(String msg) {
		super(msg);
	}
}
