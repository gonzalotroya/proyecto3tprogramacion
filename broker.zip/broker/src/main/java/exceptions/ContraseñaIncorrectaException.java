package exceptions;

public class Contrase�aIncorrectaException extends Exception {
	public Contrase�aIncorrectaException(String msg) {
		super(msg);
	}
}
